function a_gamout = a_gam(xL)

a_gamout = 4.2797*xL + 1.6216;

end

%this is the a term in the gamma distribution fit to D/AD data
