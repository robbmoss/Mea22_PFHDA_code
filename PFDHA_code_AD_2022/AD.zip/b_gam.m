function b_gamout = b_gam(xL)

b_gamout = -0.5003*xL + 0.5133;

end

%this is the b term in the gamma distribution fit to the D/AD data
