function a_gamout = a_gam(xL)

a_gamout = 1.4244*xL + 1.856;

end

%this is the a term in the gamma distribution fit to D/MD data
