function b_gamout = b_gam(xL)

b_gamout = -0.0832*xL +0.1994;

end

%this is the b term in the gamma distribution fit to the D/MD data
